export const URL = 'https://newsapi.org/v2/top-headlines?country=in&apiKey=11f0dc28d8874be0bb82287cbcf26121';
//export default URL;